<?php
/**
 * Plugin Name: Post Swiper
 * Plugin URI: 
 * Description: Block Post Challenge Plugin.
 * Author: Challenge
 * Author URI: 
 * Version: 1.1.0
 * License: 
 * License URI: 
 *
 * @package post-swiper
 *
 * 2022  Challenge
 */

namespace Tyme\PostSwiper\Core;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TYME_DIR', plugin_dir_path( __FILE__ ) );
define( 'TYME_URL', plugin_dir_url( __FILE__ ) );

require_once TYME_DIR . 'src/classes/class-postswiper.php';

\Tyme\PostSwiper\Core\PostSwiper::get_instance();
