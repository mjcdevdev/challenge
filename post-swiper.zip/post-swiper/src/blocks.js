/**
 * Import Gutenberg Blocks
 *
 * @author	Challenge
 * @package tyme-post-swiper
 */

import './block/block.js';
